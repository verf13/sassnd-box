import pygame
import random

pygame.init()

# Window instellingen
WIDTH, HEIGHT = 600, 400
BLACK = (0, 0, 0)
GRAY = (150, 150, 150)
BLUE = (0, 120, 215)

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Element Spel - Water en Vuur")

clock = pygame.time.Clock()
font = pygame.font.SysFont(None, 25)

# Slot instellingen
slot_width, slot_height = 80, 40
spacing = 20
elements = ["Water", "Vuur", "Aarde"]

slots = []
start_x = (WIDTH - (len(elements) * (slot_width + spacing) - spacing)) // 2
y = 10
for i, elem in enumerate(elements):
    x = start_x + i * (slot_width + spacing)
    rect = pygame.Rect(x, y, slot_width, slot_height)
    slots.append((rect, elem))

# --- Water class ---
class Water:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.size = 4
        self.color = BLUE

    def update(self, particles):
        if self.y + self.size < HEIGHT - 1:
            if not self.collision(self.x, self.y + self.size, particles):
                self.y += 1
            else:
                options = []
                if self.x - self.size > 0 and not self.collision(self.x - self.size, self.y, particles):
                    options.append(-1)
                if self.x + self.size < WIDTH - self.size and not self.collision(self.x + self.size, self.y, particles):
                    options.append(1)
                if options:
                    self.x += random.choice(options)

    def collision(self, x, y, particles):
        for p in particles:
            if p is not self:
                if (x < p.x + p.size and x + self.size > p.x and
                    y < p.y + p.size and y + self.size > p.y):
                    return True
        return False

    def draw(self, screen):
        pygame.draw.rect(screen, self.color, (self.x, self.y, self.size, self.size))

# --- Vuur class ---
class Vuur:
    COLORS = [(139,0,0), (255,0,0), (255,165,0), (255,255,0)]  # donkerrood, rood, oranje, geel

    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.size = 4
        self.color = random.choice(self.COLORS)

    def update(self, particles):
        if self.y - self.size > 0:
            # Ga omhoog
            if not self.collision(self.x, self.y - self.size, particles):
                self.y -= 1
            else:
                # Probeer een kant op te bewegen (links/rechts)
                options = []
                if self.x - self.size > 0 and not self.collision(self.x - self.size, self.y, particles):
                    options.append(-1)
                if self.x + self.size < WIDTH - self.size and not self.collision(self.x + self.size, self.y, particles):
                    options.append(1)
                if options:
                    self.x += random.choice(options)

    def collision(self, x, y, particles):
        for p in particles:
            if p is not self:
                if (x < p.x + p.size and x + self.size > p.x and
                    y < p.y + p.size and y + self.size > p.y):
                    return True
        return False

    def draw(self, screen):
        pygame.draw.rect(screen, self.color, (self.x, self.y, self.size, self.size))


# --- Setup ---
particles = []
selected_element = None
mouse_held = False

running = True
while running:
    screen.fill(BLACK)

    # Draw slots
    for rect, elem in slots:
        pygame.draw.rect(screen, GRAY, rect)
        pygame.draw.rect(screen, (0,0,0), rect, 2)
        text = font.render(elem, True, BLACK)
        screen.blit(text, text.get_rect(center=rect.center))

    mx, my = pygame.mouse.get_pos()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.MOUSEBUTTONDOWN:
            mouse_held = True
            for rect, elem in slots:
                if rect.collidepoint(event.pos):
                    selected_element = elem
        elif event.type == pygame.MOUSEBUTTONUP:
            mouse_held = False

    # Nieuw deeltje toevoegen
    if mouse_held and selected_element == "Water" and my > 60:
        particles.append(Water(mx, my))
    elif mouse_held and selected_element == "Vuur" and my > 60:
        particles.append(Vuur(mx, my))

    # Update alle deeltjes
    for p in particles:
        p.update(particles)

    # Teken alle deeltjes
    for p in particles:
        p.draw(screen)

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
